import javax.swing.*;
import java.text.*;

public class Librat
{
  public String emri_libres;
  public String autori;
  public int id_katalog;
  public int id_person;
  public String data;
  public int nr_huazimeve;
  public void liber_ri(int nr_librave)
   {
   
      String s="";
      s=JOptionPane.showInputDialog("Shkruaj emrin e Librit");
      emri_libres = s;
   
      s=JOptionPane.showInputDialog("Shkruaj emrin e Autorit");
      autori = s;
   
      id_katalog = nr_librave;
      data="";
      nr_huazimeve = 0;
   
   }

  public void shtyp_librat(int i)
   {
   i=i+1;
      JOptionPane.showMessageDialog(null, "Libri "+i+"\n"+"Emri: "+emri_libres+"\n"+"Autori: "+autori+"\n"+"Id "+id_katalog+"\n"+"ID personit "+id_person+"\n"+"Nr huazimeve: "+nr_huazimeve+"\n");
      
   
   }
   
   public void perditso_librin(int id_p)
   {
   id_person = id_p;
   nr_huazimeve =1;
   

   }

}

